#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>

class Course {
public:
    std::string courseNumber;
    std::string courseTitle;
    std::vector<std::string> prerequisites;
};

std::vector<Course> readCoursesFromFile(const std::string& filename) {
    std::vector<Course> courses;
    std::ifstream file(filename);

    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return courses;
    }

    std::string line;
    while (std::getline(file, line)) {
        Course course;
        std::istringstream iss(line);
        std::getline(iss, course.courseNumber, ',');
        std::getline(iss, course.courseTitle, ',');

        std::string prerequisite;
        while (std::getline(iss, prerequisite, ',')) {
            course.prerequisites.push_back(prerequisite);
        }

        courses.push_back(course);
    }

    file.close();
    return courses;
}

void printCourseList(const std::vector<Course>& courses) {
    for (const auto& course : courses) {
        std::cout << course.courseNumber << ": " << course.courseTitle << std::endl;
    }
}

void printCourse(const std::vector<Course>& courses, const std::string& courseNumber) {
    auto it = std::find_if(courses.begin(), courses.end(),
        [&courseNumber](const Course& c) { return c.courseNumber == courseNumber; });

    if (it != courses.end()) {
        std::cout << it->courseNumber << ": " << it->courseTitle << std::endl;
        if (!it->prerequisites.empty()) {
            std::cout << "Prerequisites: ";
            for (const auto& prereq : it->prerequisites) {
                std::cout << prereq << ", ";
            }
            std::cout << std::endl;
        }
    }
    else {
        std::cout << "Course not found." << std::endl;
    }
}

int main() {
    std::vector<Course> courses = readCoursesFromFile("CourseList.txt");

    int choice;
    do {
        std::cout << "Welcome to the course planner." << std::endl;
        std::cout << "1. Load Data Structure." << std::endl;
        std::cout << "2. Print Course List." << std::endl;
        std::cout << "3. Print Course." << std::endl;
        std::cout << "9. Exit" << std::endl;
        std::cout << "What would you like to do? ";
        std::cin >> choice;

        switch (choice) {
        case 1:
            std::cout << "Loading data structure..." << std::endl;
            // Implement the function to load the data structure here
            break;
        case 2:
            std::cout << "Here is a sample schedule:" << std::endl;
            printCourseList(courses);
            break;
        case 3:
        {
            std::cout << "What course do you want to know about? ";
            std::string courseNumber;
            std::cin >> courseNumber;
            printCourse(courses, courseNumber);
            break;
        }
        case 9:
            std::cout << "Thank you for using the course planner!" << std::endl;
            break;
        default:
            std::cout << choice << " is not a valid option." << std::endl;
        }
    } while (choice != 9);

    return 0;
}
